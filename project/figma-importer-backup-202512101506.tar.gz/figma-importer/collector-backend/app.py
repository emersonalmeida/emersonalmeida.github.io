from flask import Flask, request, jsonify, Response
from flask_cors import CORS
import requests

app = Flask(__name__)
CORS(app)

REQUEST_TIMEOUT = 10


@app.route('/proxy')
def proxy():
    url = request.args.get('url')
    if not url:
        return jsonify({"error": "missing url"}), 400
    try:
        r = requests.get(url, timeout=REQUEST_TIMEOUT)
        return Response(
            r.content,
            status=r.status_code,
            content_type=r.headers.get("content-type", "application/octet-stream")
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 502


@app.route('/api/collect', methods=['POST'])
def api_collect():
    body = request.get_json(silent=True) or {}
    source = body.get("source")
    term = body.get("term") or ""
    limit = int(body.get("limit") or 10)

    if not source or not term:
        return jsonify({"error": "missing source or term"}), 400

    try:
        if source == "suggest":
            url = f"https://suggestqueries.google.com/complete/search?client=firefox&q={requests.utils.requote_uri(term)}"
            r = requests.get(url, timeout=REQUEST_TIMEOUT)
            return Response(r.content, status=r.status_code, content_type="application/json")

        elif source in ["itunes", "appstore"]:
            url = f"https://itunes.apple.com/search?term={requests.utils.requote_uri(term)}&entity=software&limit={limit}"
            r = requests.get(url, timeout=REQUEST_TIMEOUT)
            return Response(r.content, status=r.status_code, content_type="application/json")

        elif source == "wiki":
            url = f"https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch={requests.utils.requote_uri(term)}&format=json"
            r = requests.get(url, timeout=REQUEST_TIMEOUT)
            return Response(r.content, status=r.status_code, content_type="application/json")

        elif source == "play":
            return jsonify({"error": "Google Play scraping não implementado neste backend mínimo."}), 501

        else:
            return jsonify({"error": "unknown source"}), 400

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)
