figma.showUI(__html__, { width: 980, height: 820 });

async function loadFonts() {
  await figma.loadFontAsync({ family: "Inter", style: "Regular" });
  await figma.loadFontAsync({ family: "Inter", style: "Medium" });
  await figma.loadFontAsync({ family: "Inter", style: "Bold" });
}

function createCardsFrame(title, items) {
  const padding = 18;
  const cardH = 86;
  const w = 920;
  const totalH = padding * 2 + items.length * (cardH + 12);

  const frame = figma.createFrame();
  frame.name = title;
  frame.resize(w, Math.min(1400, totalH));
  frame.fills = [{ type: "SOLID", color: { r: 0.98, g: 0.98, b: 0.99 } }];
  frame.x = figma.viewport.center.x - w / 2;
  frame.y = figma.viewport.center.y - (totalH / 2);

  const header = figma.createText();
  header.characters = title;
  header.fontSize = 16;
  header.fontName = { family: "Inter", style: "Bold" };
  header.x = padding;
  header.y = padding;
  frame.appendChild(header);

  let y = padding + 36;

  for (const it of items) {
    const card = figma.createFrame();
    card.resize(w - padding * 2, cardH);
    card.x = padding;
    card.y = y;
    card.cornerRadius = 10;
    card.fills = [{ type: "SOLID", color: { r: 1, g: 1, b: 1 } }];
    frame.appendChild(card);

    if (it.base64) {
      try {
        const bin = atob(it.base64);
        const arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        const img = figma.createImage(arr);

        const rect = figma.createRectangle();
        rect.resize(64, 64);
        rect.x = card.x + 14;
        rect.y = card.y + 11;
        rect.cornerRadius = 8;
        rect.fills = [{ type: "IMAGE", imageHash: img.hash, scaleMode: "FILL" }];
        frame.appendChild(rect);
      } catch {}
    }

    const titleTx = figma.createText();
    titleTx.characters = it.name || it.text || "";
    titleTx.fontSize = 13;
    titleTx.fontName = { family: "Inter", style: "Medium" };
    titleTx.x = card.x + 94;
    titleTx.y = card.y + 10;
    frame.appendChild(titleTx);

    const sub = figma.createText();
    sub.characters = it.developer || it.channel || "";
    sub.fontSize = 11;
    sub.fontName = { family: "Inter", style: "Regular" };
    sub.x = card.x + 94;
    sub.y = card.y + 30;
    frame.appendChild(sub);

    const desc = figma.createText();
    desc.characters = (it.description || "").slice(0, 200);
    desc.fontSize = 11;
    desc.x = card.x + 94;
    desc.y = card.y + 46;
    frame.appendChild(desc);

    y += cardH + 12;
  }

  figma.currentPage.appendChild(frame);
  figma.viewport.scrollAndZoomIntoView([frame]);
}

figma.ui.onmessage = async (msg) => {
  if (msg.type === "create-screens") {
    await loadFonts();
    for (const panel of msg.pack.frames) {
      createCardsFrame(panel.title, panel.items);
    }
    figma.notify("Telas criadas!");
  }

  if (msg.type === "close") figma.closePlugin();
};
